<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Controllers\BaseController;
use App\Models\User_model;

class UserController extends Controller {

    public function index() {
        helper(['form', 'url']);
        $this->User_model = new User_model();
        $data['users'] = $this->User_model->get_all_users();
        return view('User_list', $data);
    }

    public function user_add() {

        helper(['form', 'url']);
        $this->User_model = new User_model();

        $fname = $this->request->getPost('fname');
        $lname = $this->request->getPost('lname');
        $umail = $this->request->getPost('email');

        $data = array(
            'fname' => $this->request->getPost('fname'),
            'lname' => $this->request->getPost('lname'),
            'email' => $this->request->getPost('email'),
        );
        $insert = $this->User_model->user_add($data);
        echo json_encode(array("status" => TRUE));

        // Send the e-mail after record on database
        $to = "epalomba@gmail.com"; // <- ****** CHANGE ADMIN EMAIL HERE ******
        $subject = "New User Registered - " . $fname . " " . $lname;
        $message = "<b>A new user was registered:</b><br /><br />" .
                   "<b>First Name: </b>" . $fname . "<br />" .
                   "<b>Last Name: </b>" . $lname . "<br />" .
                   "<b>E-mail: </b>" . $umail . "<hr />" .
                   "This e-mail is part of a Eduardo Palomba CRUD/White Label Exercise for School of Whales.";
        $email = \Config\Services::email();
        $email->setTo($to);
        $email->setFrom('edupalombadevtest@gmail.com', 'DevTest - Eduardo Palomba');
        $email->setReplyTo($umail);
        $email->setSubject($subject);
        $email->setMessage($message);
 
        if ($email->send()) {
            //$response = 'Email successfully sent';
        } 
        else 
        {
            //$data = $email->printDebugger(['headers']);
            //$response ='Email send failed';
        }

    }

    public function ajax_edit($id) {
        $this->User_model = new User_model();
        $data = $this->User_model->get_by_id($id);
        echo json_encode($data);
    }

    public function user_update() {
        helper(['form', 'url']);
        $this->User_model = new User_model();
        $data = array(
            'fname' => $this->request->getPost('fname'),
            'lname' => $this->request->getPost('lname'),
            'email' => $this->request->getPost('email'),
        );
        $this->User_model->user_update(array('user_id' => $this->request->getPost('user_id')), $data);
        echo json_encode(array("status" => TRUE));
    }

    public function user_delete($id) {
        helper(['form', 'url']);
        $this->User_model = new User_model();
        $this->User_model->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }

}