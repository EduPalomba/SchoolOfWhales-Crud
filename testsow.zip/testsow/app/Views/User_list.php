<!DOCTYPE html>

<html>

    <head>
        <title>School of Whales - CRUD/White Label Exercise by Eduardo Palomba</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready( function () {
                $('#table_id').DataTable();
            } );
            var save_method; //for save method string
            var table;

            function add_user() {
                save_method = 'add';
                $('#form')[0].reset(); // reset form on modals
                $('#modal_form').modal('show'); // show bootstrap modal
            }

            function edit_user(id) {
                save_method = 'update';
                $('#form')[0].reset(); // reset form on modals
                <?php header('Content-type: application/json'); ?>
                //Ajax Load data from ajax
            
                $.ajax({
                    url : "<?php echo base_url('./public/UserController/ajax_edit')?>/" + id,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data)
                    {
                        console.log(data);

                        $('[name="user_id"]').val(data.user_id);
                        $('[name="fname"]').val(data.fname);
                        $('[name="lname"]').val(data.lname);
                        $('[name="email"]').val(data.email);

                        $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                        $('.modal-title').text('Edit User'); // Set title to Bootstrap modal title

                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        console.log('Error: ' + errorThrown + ' ' + textStatus + ' ' + jqXHR);
                        alert('Error get data from ajax');
                    }
                });
            }

            function save() {
                var url;

                if (save_method == 'add') {
                    url = "<?php echo base_url('./public/UserController/user_add')?>";
                } else {
                    url = "<?php echo base_url('./public/UserController/user_update')?>";
                }

                // ajax adding data to database
                $.ajax({
                    url : url,
                    type: "POST",
                    data: $('#form').serialize(),
                    dataType: "JSON",
                    success: function(data)
                    {
                    //if success close modal and reload ajax table
                    $('#modal_form').modal('hide');
                    location.reload();// for reload a page
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        console.log('Error: ' + errorThrown + ' ' + textStatus + ' ' + jqXHR);
                        alert('Error adding / update data');
                        location.reload();// for reload a page
                    }
                });
            }

            function delete_user(id) {
                if(confirm('Are you sure delete this data?')) {
                    // ajax delete data from database
                    $.ajax({
                        url : "<?php echo base_url('./public/UserController/user_delete') ?>/"+id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data)
                        {
                            location.reload();
                        },
                        error: function(jqXHR, textStatus, errorThrown)
                        {
                            console.log('Error: ' + errorThrown + ' ' + textStatus + ' ' + jqXHR);
                            alert('Error deleting data');
                            location.reload();
                        }
                    });
              }
            }
        </script>
    </head>
    <body>
        <div class="container">

            <h3>School of Whales - White Label Exercise by Eduardo Palomba</h3>
            <br />
            <button class="btn btn-success" onclick="add_user()">Add User</button>
            <br /><br />

            <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>User Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>E-mail</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users as $user){?>
                    <tr>
                        <td><?php echo $user->user_id;?></td>
                        <td><?php echo $user->fname;?></td>
                        <td><?php echo $user->lname;?></td>
                        <td><?php echo $user->email;?></td>
                        <td align="center">
                            <button class="btn btn-warning" onclick="edit_user(<?php echo $user->user_id;?>)">Edit</button>
                            <button class="btn btn-danger " onclick="delete_user(<?php echo $user->user_id;?>)">Delete</button>
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>User Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>E-mail</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <!-- Bootstrap modal -->

        <div class="modal fade" id="modal_form" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&nbsp;x&nbsp;</span></button>
                        <h3 class="modal-title">Add User Form</h3>
                    </div>
                    <div class="modal-body form">
                        <form action="#" id="form" class="form-horizontal">
                            <input type="hidden" value="" name="user_id"/>
                            <div class="form-body">
                                <div class="form-group">
                                    <label class="control-label col-md-3">First Name</label>
                                    <div class="col-md-9">
                                        <input name="fname" placeholder="First Name" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Last Name</label>
                                    <div class="col-md-9">
                                        <input name="lname" placeholder="Last Name" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">E-mail</label>
                                    <div class="col-md-9">
                                        <input name="email" placeholder="E-mail" class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
  
        <!-- End Bootstrap modal -->
    </body>
</html>